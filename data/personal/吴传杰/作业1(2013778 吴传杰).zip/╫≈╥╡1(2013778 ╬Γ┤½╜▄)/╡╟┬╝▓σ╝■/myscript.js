alert("NiePeng is so handsome!");
document.getElementById("user[email]").value="1487743280@qq.com";
document.getElementById("user[password]").value="***********";/*正常应为真正登录网站的密码*/ 



